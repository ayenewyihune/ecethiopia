<template>
    <h2>This is home</h2>
</template>

<script>
export default {
    name: "PublicHome"
}
</script>

<style>

</style>
