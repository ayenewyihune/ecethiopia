<template>
  
</template>

<script>
export default {
  name: "ProfessionalProfile"
};
</script>

<style>
</style>
